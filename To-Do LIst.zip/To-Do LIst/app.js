const input = document.querySelector("#input");
const add = document.querySelector("#button");
const addTask = document.querySelector("#task");


add.addEventListener('click' ,() =>{
    const data = input.value;

    const task = document.createElement('p');
    task.innerHTML = `<img src="images/unchecked.png" class="uncheck">
                    <span id="work">${data}</span>
                    <img src="images/cross.png" class="delete">`;

    addTask.append(task);

    input.value = "";

});
document.addEventListener('click', (event) =>{
    if(event.target.classList.contains("uncheck")){
        event.target.src = "images/checked.png";
        event.target.classList.remove("uncheck");
        event.target.classList.add("checked");
    }
    else if(event.target.classList.contains("checked")){
        event.target.src = "images/unchecked.png";
        event.target.classList.remove("checked");
        event.target.classList.add("uncheck");
    }
})
document.addEventListener('click', (event)=>{
    if(event.target.classList.contains("delete")){
        const val = event.target.parentElement;

        val.classList.add("fade-out");

        setTimeout(() => {
            val.remove();
        }, 400);
    }

    
})